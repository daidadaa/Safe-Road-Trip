
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public int score = 0;

    public void AddScore(bool correct)
    {
        if (correct) score++;
        Debug.Log("Score: " + score);
    }
}
