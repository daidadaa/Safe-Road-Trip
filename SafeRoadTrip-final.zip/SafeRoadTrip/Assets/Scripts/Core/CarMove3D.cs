using UnityEngine;

public class CarMove3D : MonoBehaviour
{
    public float speed = 8f;
    public TrafficLightController trafficLight;

    void Update()
    {
        // 🚦 红灯停
       if (trafficLight.IsRed())
    return;
        transform.Translate(Vector3.forward * speed * Time.deltaTime);
    }
}