using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public GameObject resultPanel;
    public TextMeshProUGUI resultText;

    public GameObject retryButton;
    public GameObject nextButton;

    bool gameEnded = false;

    void Awake()
    {
        // 初始化UI
        resultPanel.SetActive(false);

        // 时间恢复
        Time.timeScale = 1f;

        // ⭐ 游戏开始：锁鼠标
        LockCursor();
    }

    // 🔒 锁鼠标（游戏状态）
    void LockCursor()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    // 🔓 解锁鼠标（UI状态）
    void UnlockCursor()
    {
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    // ❌ 游戏失败
    public void GameOver(string reason)
    {
        if (gameEnded) return;
        gameEnded = true;

        Time.timeScale = 0f;

        UnlockCursor(); // ⭐关键

        resultPanel.SetActive(true);
        resultText.text = "YOU LOST\n" + reason;

        retryButton.SetActive(true);
        nextButton.SetActive(false);
    }

    // ✅ 游戏胜利
    public void Win()
    {
        if (gameEnded) return;
        gameEnded = true;

        Time.timeScale = 0f;

        UnlockCursor(); // ⭐关键

        resultPanel.SetActive(true);
        resultText.text = "YOU WIN";

        retryButton.SetActive(true);
        nextButton.SetActive(true);
    }

    // 🔁 重来
    public void Retry()
    {
        Debug.Log("点击了 Retry");

        Time.timeScale = 1f;

        LockCursor(); // ⭐重新锁

        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    // ➡️ 下一关
    public void NextLevel()
    {
        Time.timeScale = 1f;

        LockCursor(); // ⭐重新锁

        SceneManager.LoadScene("Level"); // ⚠️ 必须存在
    }
}