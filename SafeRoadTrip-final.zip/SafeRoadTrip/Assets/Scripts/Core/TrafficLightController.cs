using UnityEngine;   // ⭐ 必须有
using TMPro;

public class TrafficLightController : MonoBehaviour
{
    public GameObject redLight;
    public GameObject yellowLight;
    public GameObject greenLight;

    public TMP_Text timerText;

    public float redTime = 10f;
    public float greenTime = 8f;
    public float yellowTime = 3f;

    float timer;
    public int state = 0;

    void Start()
    {
        SetRed();
    }

    void Update()
    {
        timer -= Time.deltaTime;

        if (timerText != null)
            timerText.text = Mathf.Ceil(timer).ToString();

        if (timer <= 0)
        {
            if (state == 0) SetGreen();
            else if (state == 1) SetYellow();
            else SetRed();
        }
    }

    void SetRed()
    {
        state = 0;
        timer = redTime;

        redLight.SetActive(true);
        yellowLight.SetActive(false);
        greenLight.SetActive(false);

        timerText.color = Color.red;
    }

    void SetGreen()
    {
        state = 1;
        timer = greenTime;

        redLight.SetActive(false);
        yellowLight.SetActive(false);
        greenLight.SetActive(true);

        timerText.color = Color.green;
    }

    void SetYellow()
    {
        state = 2;
        timer = yellowTime;

        redLight.SetActive(false);
        yellowLight.SetActive(true);
        greenLight.SetActive(false);

        timerText.color = Color.yellow;
    }
    public bool IsRed()
{
    return state == 0;
}
}