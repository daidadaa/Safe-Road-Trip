using UnityEngine;

public class CrosswalkCheck : MonoBehaviour
{
    public TrafficLightController trafficLight;
    public GameManager gameManager;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (trafficLight.IsRed())
            {
                gameManager.GameOver("Red Light Violation ");
            }
        }
    }
}