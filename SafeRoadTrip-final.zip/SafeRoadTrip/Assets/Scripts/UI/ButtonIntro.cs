using UnityEngine;
using System.Collections;

public class ButtonIntro : MonoBehaviour
{
    public float delay;

    void Start()
    {
        transform.localScale = Vector3.zero;
        StartCoroutine(Show());
    }

    IEnumerator Show()
    {
        yield return new WaitForSeconds(delay);

        float t = 0;
        while (t < 1)
        {
            t += Time.deltaTime * 4;
            transform.localScale = Vector3.Lerp(Vector3.zero, Vector3.one, t);
            yield return null;
        }
    }
}