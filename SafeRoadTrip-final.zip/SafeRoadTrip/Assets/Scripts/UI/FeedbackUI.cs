
using UnityEngine;
using TMPro;

public class FeedbackUI : MonoBehaviour
{
    public TMP_Text feedbackText;

    public void Show(string msg)
    {
        feedbackText.text = msg;
    }
}
