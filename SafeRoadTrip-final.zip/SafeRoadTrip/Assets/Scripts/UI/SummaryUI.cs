
using UnityEngine;
using TMPro;

public class SummaryUI : MonoBehaviour
{
    public TMP_Text summaryText;

    public void ShowScore(int score)
    {
        summaryText.text = "Final Score: " + score;
    }
}
