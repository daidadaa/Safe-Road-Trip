using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;

public class ButtonClick : MonoBehaviour, IPointerClickHandler
{
    public void OnPointerClick(PointerEventData eventData)
    {
        StartCoroutine(Click());
    }

    IEnumerator Click()
    {
        transform.localScale *= 0.9f;
        yield return new WaitForSeconds(0.1f);
        transform.localScale *= 1.1f;
    }
}