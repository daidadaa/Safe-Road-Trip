using UnityEngine;

public class CardSlide : MonoBehaviour
{
    Vector3 startPos;
    Vector3 targetPos;

    float time = 0;
    public float duration = 1.2f; // 控制动画总时长

    void Start()
    {
        targetPos = transform.localPosition;

        // 设置起点
        if (targetPos.x < 0)
            startPos = targetPos + new Vector3(-600, 0, 0);
        else
            startPos = targetPos + new Vector3(600, 0, 0);

        transform.localPosition = startPos;
    }

    void Update()
    {
        time += Time.deltaTime;

        float t = time / duration;
        t = Mathf.Clamp01(t);

        // ⭐ 平滑缓动（不会抽搐）
        t = Mathf.SmoothStep(0, 1, t);

        transform.localPosition = Vector3.Lerp(startPos, targetPos, t);

        // ⭐ 到终点直接锁死（彻底防抖）
        if (t >= 1f)
        {
            transform.localPosition = targetPos;
            enabled = false; // 停止Update（关键！）
        }
    }
}