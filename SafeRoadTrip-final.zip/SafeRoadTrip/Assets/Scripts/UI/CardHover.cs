using UnityEngine;
using UnityEngine.EventSystems;

public class CardHover : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
{
    Vector3 originalScale;
    Vector3 targetScale;

    Vector3 originalPos;
    Vector3 targetPos;

    public float scaleAmount = 1.1f;
    public float moveUp = 20f;
    public float speed = 8f;

    bool isHover = false;

    void Start()
    {
        originalScale = transform.localScale;
        targetScale = originalScale;

        originalPos = transform.localPosition;
        targetPos = originalPos;
    }

    void Update()
    {
        transform.localScale = Vector3.Lerp(transform.localScale, targetScale, Time.deltaTime * speed);
        transform.localPosition = Vector3.Lerp(transform.localPosition, targetPos, Time.deltaTime * speed);
    }

    // 鼠标进入
    public void OnPointerEnter(PointerEventData eventData)
    {
        isHover = true;
        targetScale = originalScale * scaleAmount;
        targetPos = originalPos + new Vector3(0, moveUp, 0);
    }

    // 鼠标离开
    public void OnPointerExit(PointerEventData eventData)
    {
        isHover = false;
        targetScale = originalScale;
        targetPos = originalPos;
    }

    // 鼠标按下
    public void OnPointerDown(PointerEventData eventData)
    {
        targetScale = originalScale * 0.95f;
    }

    // 鼠标松开
    public void OnPointerUp(PointerEventData eventData)
    {
        if (isHover)
        {
            targetScale = originalScale * scaleAmount;
        }
        else
        {
            targetScale = originalScale;
        }
    }
}