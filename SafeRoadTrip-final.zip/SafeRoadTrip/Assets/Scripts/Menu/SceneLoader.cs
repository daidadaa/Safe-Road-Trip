using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{
    // 👉 通过名字加载
    public void LoadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }

    // 👉 通过编号加载
    public void LoadSceneByIndex(int index)
    {
        SceneManager.LoadScene(index);
    }

    // 👉 退出游戏
    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Game Quit"); // 在Unity里测试用
    }
}