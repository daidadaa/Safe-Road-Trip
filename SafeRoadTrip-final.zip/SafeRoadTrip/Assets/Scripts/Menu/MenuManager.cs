using UnityEngine;

public class MenuManager : MonoBehaviour
{
    void Start()
    {
        // ⭐ 进入菜单时强制解锁鼠标
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        // 防止时间暂停残留
        Time.timeScale = 1f;
    }
}