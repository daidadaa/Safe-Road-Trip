using UnityEngine;

public class TitlePulse : MonoBehaviour
{
    float speed = 2f;
    float scaleAmount = 0.05f;

    Vector3 startScale;

    void Start()
    {
        startScale = transform.localScale;
    }

    void Update()
    {
        float scale = 1 + Mathf.Sin(Time.time * speed) * scaleAmount;
        transform.localScale = startScale * scale;
    }
}