using UnityEngine;

public class MenuButton : MonoBehaviour
{
    public void OnClick()
    {
        Debug.Log("Menu button clicked");
    }
}