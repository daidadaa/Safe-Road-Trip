
using UnityEngine;

public class Bin : MonoBehaviour
{
    public string binType;

    public bool CheckItem(string itemType)
    {
        return itemType == binType;
    }
}
