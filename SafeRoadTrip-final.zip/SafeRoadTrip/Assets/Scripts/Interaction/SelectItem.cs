
using UnityEngine;

public class SelectItem : MonoBehaviour
{
    public string itemType;

    public void Select()
    {
        Debug.Log("Selected: " + itemType);
    }
}
